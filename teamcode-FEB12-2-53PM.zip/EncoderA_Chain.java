package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;

@Autonomous(name = "EncoderA_Chain (Blocks to Java)", group = "")
@Disabled
public class EncoderA_Chain extends LinearOpMode {

  private DcMotor frontLeftWheelAsDcMotor;
  private DcMotor backLeftWheelAsDcMotor;
  private DcMotor frontRightWheelAsDcMotor;
  private DcMotor backRightWheelAsDcMotor;

  /**
   * This function is executed when this Op Mode is selected from the Driver Station.
   */
  @Override
  public void runOpMode() {
    frontLeftWheelAsDcMotor = hardwareMap.dcMotor.get("frontLeftWheelAsDcMotor");
    backLeftWheelAsDcMotor = hardwareMap.dcMotor.get("backLeftWheelAsDcMotor");
    frontRightWheelAsDcMotor = hardwareMap.dcMotor.get("frontRightWheelAsDcMotor");
    backRightWheelAsDcMotor = hardwareMap.dcMotor.get("backRightWheelAsDcMotor");

    // Put initialization blocks here
    frontLeftWheelAsDcMotor.setDirection(DcMotorSimple.Direction.REVERSE);
    backLeftWheelAsDcMotor.setDirection(DcMotorSimple.Direction.REVERSE);
    frontRightWheelAsDcMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
    frontLeftWheelAsDcMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
    frontRightWheelAsDcMotor.setTargetPosition(7200);
    frontLeftWheelAsDcMotor.setTargetPosition(7200);
    frontRightWheelAsDcMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
    frontLeftWheelAsDcMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
    waitForStart();
    frontRightWheelAsDcMotor.setPower(1);
    frontLeftWheelAsDcMotor.setPower(1);
    backRightWheelAsDcMotor.setPower(1);
    backLeftWheelAsDcMotor.setPower(1);
    while (!(!frontLeftWheelAsDcMotor.isBusy() || !frontRightWheelAsDcMotor.isBusy())) {
      // Put loop blocks here
      telemetry.addData("TickFR", frontRightWheelAsDcMotor.getCurrentPosition());
      telemetry.addData("TicksFL", frontLeftWheelAsDcMotor.getCurrentPosition());
      telemetry.update();
    }
    // Put run blocks here.
    frontLeftWheelAsDcMotor.setPower(0);
    frontRightWheelAsDcMotor.setPower(0);
    backRightWheelAsDcMotor.setPower(0);
    backLeftWheelAsDcMotor.setPower(0);
    sleep(1000);
    frontLeftWheelAsDcMotor.setDirection(DcMotorSimple.Direction.FORWARD);
    backLeftWheelAsDcMotor.setDirection(DcMotorSimple.Direction.FORWARD);
    frontRightWheelAsDcMotor.setDirection(DcMotorSimple.Direction.REVERSE);
    backRightWheelAsDcMotor.setDirection(DcMotorSimple.Direction.REVERSE);
    frontRightWheelAsDcMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
    frontLeftWheelAsDcMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
    frontLeftWheelAsDcMotor.setTargetPosition(400);
    frontRightWheelAsDcMotor.setTargetPosition(400);
    frontRightWheelAsDcMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
    frontLeftWheelAsDcMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
    waitForStart();
    frontLeftWheelAsDcMotor.setPower(0.1);
    frontRightWheelAsDcMotor.setPower(0.1);
    backLeftWheelAsDcMotor.setPower(0.1);
    backRightWheelAsDcMotor.setPower(0.1);
    while (!(!frontLeftWheelAsDcMotor.isBusy() || !frontRightWheelAsDcMotor.isBusy())) {
      // Put loop blocks here
    }
    frontLeftWheelAsDcMotor.setPower(0);
    frontRightWheelAsDcMotor.setPower(0);
    backLeftWheelAsDcMotor.setPower(0);
    backRightWheelAsDcMotor.setPower(0);
  }
}
