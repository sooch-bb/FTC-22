package org.firstinspires.ftc.teamcode;

import android.graphics.Color;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import org.firstinspires.ftc.robotcore.external.JavaUtil;

@Autonomous(name = "StopAtWhiteUC (Blocks to Java)", group = "")
public class StopAtWhiteUC extends LinearOpMode {

  private DcMotor frontLeftWheel;
  private DcMotor backLeftWheel;
  private DcMotor frontRightWheel;
  private DcMotor backRightWheel;
  private ColorSensor colorLeft_REV_ColorRangeSensor;

  /**
   * This function is executed when this Op Mode is selected from the Driver Station.
   */
  @Override
  public void runOpMode() {
    int CurrentColor;

    frontLeftWheel = hardwareMap.get(DcMotor.class, "frontLeftWheel");
    backLeftWheel = hardwareMap.get(DcMotor.class, "backLeftWheel");
    frontRightWheel = hardwareMap.get(DcMotor.class, "frontRightWheel");
    backRightWheel = hardwareMap.get(DcMotor.class, "backRightWheel");
    colorLeft_REV_ColorRangeSensor = hardwareMap.get(ColorSensor.class, "colorLeft");

    // Put initialization blocks here.
    frontLeftWheel.setDirection(DcMotorSimple.Direction.REVERSE);
    backLeftWheel.setDirection(DcMotorSimple.Direction.REVERSE);
    sleep(500);
    waitForStart();
    frontLeftWheel.setPower(0.8);
    backLeftWheel.setPower(0.8);
    frontRightWheel.setPower(0.8);
    backRightWheel.setPower(0.8);
    // Put run blocks here.
    while (opModeIsActive()) {
      // Put loop blocks here.
      CurrentColor = Color.rgb(colorLeft_REV_ColorRangeSensor.red(), colorLeft_REV_ColorRangeSensor.green(), colorLeft_REV_ColorRangeSensor.blue());
      if (JavaUtil.colorToHue(CurrentColor) > 100 && JavaUtil.colorToHue(CurrentColor) < 125 && JavaUtil.colorToValue(CurrentColor) > 0.35) {
        frontLeftWheel.setPower(0);
        backLeftWheel.setPower(0);
        frontRightWheel.setPower(0);
        backRightWheel.setPower(0);
      }
      telemetry.addData("Red", colorLeft_REV_ColorRangeSensor.red());
      telemetry.addData("Blue", colorLeft_REV_ColorRangeSensor.blue());
      telemetry.addData("Green", colorLeft_REV_ColorRangeSensor.green());
      telemetry.addData("Hue", JavaUtil.colorToHue(CurrentColor));
      telemetry.addData("Saturation", JavaUtil.colorToSaturation(CurrentColor));
      telemetry.addData("Value", JavaUtil.colorToValue(CurrentColor));
      telemetry.update();
    }
  }
}
